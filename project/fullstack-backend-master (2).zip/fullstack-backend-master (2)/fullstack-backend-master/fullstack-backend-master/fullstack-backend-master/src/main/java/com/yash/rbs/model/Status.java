package com.yash.rbs.model;

public enum Status {
    SUCCESS,
    USER_ALREADY_EXISTS,
    FAILURE
}